package com.cg.capbook.beans;

import java.util.Arrays;

import javax.persistence.Embeddable;
@Embeddable
public class Images {

	private String imageName;
	private byte[] image;
	
	public Images() {}
	
	public Images(String imageName, byte[] image) {
		super();
		this.imageName = imageName;
		this.image = image;
	}
	
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(image);
		result = prime * result + ((imageName == null) ? 0 : imageName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Images other = (Images) obj;
		if (!Arrays.equals(image, other.image))
			return false;
		if (imageName == null) {
			if (other.imageName != null)
				return false;
		} else if (!imageName.equals(other.imageName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Images [imageName=" + imageName + ", image=" + Arrays.toString(image) + "]";
	}
	

}

package com.cg.capbook.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Users;
import com.cg.capbook.beans.Post;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.EmailAlreadyExistException;
import com.cg.capbook.exceptions.PasswordMismatchException;
import com.cg.capbook.exceptions.SecurityAnswerMismatchException;
import com.cg.capbook.exceptions.SecurityQuestionMismatchException;
import com.cg.capbook.services.CapBookServices;

@Controller
@SessionAttributes("emailId")
public class CapBookServiceController {
	@Autowired
	CapBookServices services;
	
	

	@RequestMapping("/registerUserService")
	public ModelAndView registerUser(@Valid@ModelAttribute Users user,BindingResult result) throws UserDetailsNotFoundException, EmailAlreadyExistException {
		if(result.hasErrors()) return new ModelAndView("registrationPage");
		user = services.acceptUserDetails(user);
		return new ModelAndView("indexPage","user",user);
	}

	@RequestMapping("/loginUserService")
	public ModelAndView getUserDetails(@RequestParam String emailId, @RequestParam String password,ModelMap model) throws UserDetailsNotFoundException{ 
		String encryptedPassword=services.encryptPassword(password);
		Users user = services.getUserDetails(emailId);
		String originalEncryptedPassword=user.getPassword();
		if(originalEncryptedPassword.equals(encryptedPassword)) {
			model.put("emailId", user.getEmailId());
			return new ModelAndView("homePage","emailId",emailId);
		}
		else throw new PasswordMismatchException("Password is not correct");
	}

	@RequestMapping("/userProfileService")
	public ModelAndView userProfile(@SessionAttribute("emailId") String emailId) throws UserDetailsNotFoundException {
		Users user=services.getUserDetails(emailId);
		return new ModelAndView("userProfilePage","user",user);
	}
	
	@RequestMapping("/forgetPasswordService")
	public ModelAndView getAssociateDetails(@ModelAttribute Users user) throws UserDetailsNotFoundException, SecurityAnswerMismatchException, SecurityQuestionMismatchException{
		String emailId=user.getEmailId();
		String securityQuestion=user.getSecurityQuestion();
		String securityAnswer=user.getSecurityAnswer();
		Users userValidate = services.getUserDetails(emailId);
		if(userValidate.getSecurityQuestion().equals(securityQuestion)) {
			if(userValidate.getSecurityAnswer().equals(securityAnswer)) {
				services.updateUserDetails(emailId);
				return new ModelAndView("indexPage","user",user);
			}
			else throw new SecurityAnswerMismatchException("Security answer mismatch");
		}
		else throw new SecurityQuestionMismatchException("Security Question Mismatch");
	}
	
	/*
	 * @RequestMapping( "/getProfilePic") public ResponseEntity<byte[]> getImage()
	 * throws IOException { return
	 * ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(services.
	 * fetchProfilePic()); }
	 */
	@RequestMapping("/postStatusService")
	public ModelAndView savePostDetails(@ModelAttribute Post post,@SessionAttribute("emailId") String emailId) throws UserDetailsNotFoundException{ 
		
		post.setUser(services.getUserDetails(emailId));
		return new ModelAndView("homePage","posts",services.savePost(post));
	}
	
}

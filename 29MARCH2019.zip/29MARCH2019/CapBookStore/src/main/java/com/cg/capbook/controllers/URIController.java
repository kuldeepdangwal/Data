package com.cg.capbook.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capbook.beans.Users;
import com.cg.capbook.beans.Post;

@Controller
public class URIController {
	

	
	@RequestMapping(value= {"/","index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	
	
	@RequestMapping("/forgetPassword")
	public String getForgetPasswordPage() {
		return "forgetPasswordPage";
	}
	
	@ModelAttribute
	public Users getUsers() {
		return new Users();
	}
	
	@ModelAttribute
	public Post getPost() {
		return new Post();
	}

}

package com.cg.capbook.exceptions;

@SuppressWarnings("serial")
public class SecurityQuestionMismatchException extends Exception{

	public SecurityQuestionMismatchException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SecurityQuestionMismatchException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SecurityQuestionMismatchException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SecurityQuestionMismatchException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SecurityQuestionMismatchException() {
		// TODO Auto-generated constructor stub
	}

}

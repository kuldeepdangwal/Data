package com.cg.capbook.services;

import java.util.List;

import com.cg.capbook.beans.Users;
import com.cg.capbook.beans.Post;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.EmailAlreadyExistException;
import com.cg.capbook.exceptions.PasswordMismatchException;

public interface CapBookServices {
	Users acceptUserDetails(Users user) throws UserDetailsNotFoundException, EmailAlreadyExistException;
	Users getUserDetails(String emailId) throws UserDetailsNotFoundException;
	boolean deleteUserDetails(String emailId) throws UserDetailsNotFoundException;
	Users updateUserDetails(String emailId) throws UserDetailsNotFoundException;
	String encryptPassword(String password);
	String decryptPassword(String password);
	boolean changePassword(String emailId,String newPassword,String confirmPassword) throws UserDetailsNotFoundException,PasswordMismatchException;
	Post savePost(Post post);
	List<Post> getAllPost();
	//Customer saveProfilePicture(String emailId,MultipartFile File) throws CustomerDetailsNotFoundException;
}
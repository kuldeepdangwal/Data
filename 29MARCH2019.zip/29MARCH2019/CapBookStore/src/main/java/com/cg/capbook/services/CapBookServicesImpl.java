package com.cg.capbook.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Users;
import com.cg.capbook.beans.Post;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.daoservices.PostDAO;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.EmailAlreadyExistException;
import com.cg.capbook.exceptions.PasswordMismatchException;

@Component("capBookServices")
public class CapBookServicesImpl implements CapBookServices {
	
	String url="C:\\Users\\ADM-IG-HWDLAB1D\\git\\CapBookLocalRepoTeam7\\CapBookStore\\src\\main\\resources\\static\\images\\UserImages";

	@Autowired
	private UserDAO  userDao;
	@Autowired
	private PostDAO postDao;

	@Override
	public Users acceptUserDetails(Users user) throws UserDetailsNotFoundException, EmailAlreadyExistException {
		String password=user.getPassword();
		String encryptedPassword=encryptPassword(password);
		user.setPassword(encryptedPassword);
		LocalDate joinDate = LocalDate.now();
		DateTimeFormatter formatters =DateTimeFormatter.ofPattern("yyyyMMdd");
		String text=joinDate.format(formatters);
		LocalDate parsedDate = LocalDate.parse(text,formatters); 
		user.setJoinDate(parsedDate);
		return userDao.save(user);
	}

	@Override
	public Users getUserDetails(String emailId) throws UserDetailsNotFoundException {
		Users user=userDao.findById(emailId).orElseThrow(()->new UserDetailsNotFoundException("user does not exist!!"));
		return user;
	}

	@Override
	public boolean deleteUserDetails(String emailId) throws UserDetailsNotFoundException {
		userDao.delete(getUserDetails(emailId));
		return true;
	}

	@Override
	public Users updateUserDetails(String emailId) throws UserDetailsNotFoundException {
		Users user=getUserDetails(emailId);
		user=userDao.save(user);
		return user;
	}

	@Override
	public String encryptPassword(String password) {
		return Base64.getMimeEncoder().encodeToString(password.getBytes());
	}

	@Override
	public String decryptPassword(String password) {
		return new String(Base64.getMimeDecoder().decode(password));
	}

	@Override
	public boolean changePassword(String emailId,String newPassword,String confirmPassword) throws UserDetailsNotFoundException,PasswordMismatchException {
		Users user= getUserDetails(emailId);
		String oldPassword=user.getPassword();
		if(oldPassword.equals(newPassword))
			throw new PasswordMismatchException("New password can not be same as old password. Please re-enter new password.");
		else 
			if(!(newPassword.equals(confirmPassword))) {
				throw new PasswordMismatchException("Confirm Password and New Password should be same.");
			}		
		user.setPassword(confirmPassword);
		userDao.save(user);
		return true;
	}

	@Override
	public Post savePost(Post post) {
		LocalDateTime now = LocalDateTime.now();    
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMdd HHmmss");  
        String formatDateTime = now.format(format);  
		LocalDateTime parsedDate = LocalDateTime.parse(formatDateTime,format); 
		post.setDateTime(parsedDate);
		return postDao.save(post);
		
	}

	@Override
	public List<Post> getAllPost() {
		return postDao.findAll();
	}
//	For Saving Profile Picture
//	@Override
//	public user saveProfilePicture(String emailId, MultipartFile File) throws userDetailsNotFoundException {
//		user user=userDao.findById(emailId).orElseThrow(()->new userDetailsNotFoundException("user does not exist!!"));
//	
//		try {
//			File.transferTo(Paths.get(url+File.getOriginalFilename()));
//			user.setProfilePicture("/UserImages/"+File.getOriginalFilename());
//		} catch (IllegalStateException | IOException e) {
//			e.printStackTrace();
//		}
//	return userDao.save(user);
//	}


}
(function ($) {
	"use strict";

	/*==================================================================
    [ Validate ]*/
	var input = $('.validate-input .input100');

	$('.validate-form').on('submit',function(){
		var check = true;

		for(var i=0; i<input.length; i++) {
			if(validate(input[i]) == false){
				showValidate(input[i]);
				check=false;
			}
		}

		return check;
	});

	$('.validate-form .input100').each(function(){
		$(this).focus(function(){
			hideValidate(this);
		});
	});
	
	function validate (input) {
		if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
			if($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
				return false;
			}
		}
		else {
			if($(input).val().trim() == ''){
				return false;
			}
		}
	}

	function showValidate(input) {
		var thisAlert = $(input).parent();

		$(thisAlert).addClass('alert-validate');
	}

	function hideValidate(input) {
		var thisAlert = $(input).parent();

		$(thisAlert).removeClass('alert-validate');
	}

})(jQuery);


/*==================================================================
[ User registration Validations ]*/
function validateUserDetails(){
	if(registrationForm.firstName.value==""){
		alert("First Name can not be empty!");
		document.registrationForm.firstName.focus();
		return false;
	}
	
	if(registrationForm.lastName.value==""){
		alert("Last Name can not be empty!");
		document.registrationForm.lastName.focus();
		return false;
	}
	
	if(registrationForm.emailId.value==""){
		alert("E-mail Id can not be empty!");
		document.registrationForm.emailId.focus();
		return false;
	}
	
	 var e = document.getElementById("gender");
	 var selectedGenderIndex = e.options[e.selectedIndex].value;
	if(selectedGenderIndex==0){
		alert("Please select a Gender!");
		document.registrationForm.gender.focus();
		return false;
	}
	
	var e = document.getElementById("securityQuestion");
	 var selectedSecurityQuestionIndex = e.options[e.selectedIndex].value;
	if(selectedSecurityQuestionIndex==0){
		alert("Please select a Security Question!");
		document.registrationForm.securityQuestion.focus();
		return false;
	}
	
	if(registrationForm.securityAnswer.value==""){
		alert("Security Answer can not be empty!");
		document.registrationForm.securityAnswer.focus();
		return false;
	}
	
	return true;
}

function validatePassword(){
	if(registrationForm.password.value.length>=6){
		if(registrationForm.password.value.search(/[0-9]/)!=-1 &&
				registrationForm.password.value.search(/[A-Z]/)!=-1 &&
				registrationForm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
			return true;
		}
		else{
			alert("Password must contain atleast 1 number, 1 uppercase letter and 1 special character!");
			document.registrationForm.password.focus();
			return false;
		}
	}
	
	else{
		alert("Password length must be of Minimum 6 characters!");
		document.registrationForm.password.focus();
		return false;
	}
}

function checkSame(){
	if(registrationForm.password.value != registrationForm.confirmPassword.value){
		alert("Password and confirm password do not match!");
		document.registrationForm.confirmPassword.focus();
		return false;
	}
	else{
		sweetAlert({ 
		    title: "Congrats", 
		    text: "Your account is created!", 
		    type: "success"
		});
		Thread.sleep(10000);
//		alert("Congrats!!!! You're successfully registered");
	}
}
/*==================================================================
[ Successful Registration Alert Box ]*/
//function successRegistrationAlert(){
//	//swal("Congrats!", ", Your account is created!", "success");
//	sweetAlert({ 
//	    title: "Congrats", 
//	    text: "Your account is created!", 
//	    type: "success" 
//	});
//}

/*==================================================================
[Forget Password Validations ]*/
function validateForgetPasswordDetails(){
	if(forgetPasswordForm.emailId.value==""){
		alert("E-mail Id can not be empty!");
		document.forgetPasswordForm.emailId.focus();
		return false;
	}
	return true;
}
/*==================================================================
[ Password type ]*/
function validateForgetPassword(){
	if(forgetPasswordForm.password.value.length>=6){
		if(forgetPasswordForm.password.value.search(/[0-9]/)!=-1 &&
				forgetPasswordForm.password.value.search(/[A-Z]/)!=-1 &&
				forgetPasswordForm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
			return true;
		}
		else{
			alert("Password must contain atleast 1 number, 1 uppercase letter and 1 special character!");
			document.forgetPasswordForm.password.focus();
			return false;
		}
	}
	else{
		alert("Password length must be of Minimum 6 characters!");
		document.forgetPasswordForm.password.focus();
	}
	return false;
}
/*==================================================================
[ Checking Both Password ]*/

function checkSameForgetPassword(){
	if(forgetPasswordForm.password.value != forgetPasswordForm.confirmPassword.value){
		alert("Password and confirm password do not match!");
		document.forgetPasswordForm.confirmPassword.focus();
		return false;
	}
	var e = document.getElementById("securityQuestion1");
	 var selectedSecurityQuestionIndex = e.options[e.selectedIndex].value;
	if(selectedSecurityQuestionIndex==0){
		alert("Please select a Security Question!");
		document.forgetPasswordForm.securityQuestion.focus();
		return false;
	}
	
	if(forgetPasswordForm.securityAnswer.value==""){
		alert("Security Answer can not be empty!");
		document.forgetPasswordForm.securityAnswer.focus();
		return false;
	}
	
	return true;
}

/*==================================================================
[ Profile Picture ]*/

$(document).ready(function() {
var readURL = function(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();

			reader.onload = function (e) {
				$('.profile-pic').attr('src', e.target.result);
			}

			reader.readAsDataURL(input.files[0]);
		}
	}


	$(".file-upload").on('change', function(){
		readURL(this);
	});

	$(".upload-button").on('click', function() {
		$(".file-upload").click();
	});
});
/*==================================================================
[ Enabling profile fields and buttons ]*/
function enableButtonFields(){
	document.getElementById("firstName").disabled=false;
	document.getElementById("lastName").disabled=false;
	document.getElementById("gender").disabled=false;
	document.getElementById("contactNumber").disabled=false;
	document.getElementById("profession").disabled=false;
}

//function disableButtonFields(){
////	document.userProfileForm.getElementByName("firstName").disabled=false;
////	document.userProfileForm.getElementByName("lastName").disabled=false;
////	document.userProfileForm.getElementByName("gender").disabled=false;
////	document.userProfileForm.getElementByName("contactNumber").disabled=false;
////	document.userProfileForm.getElementByName("profession").disabled=false;
//	document.getElementById("save").disabled=true;
//}

/*==================================================================
[ Email id alert box ]*/